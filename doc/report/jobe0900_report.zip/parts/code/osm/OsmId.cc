/*
 * OsmId.cc
 *
 * @author  Jonas Bergman
 */

#include "OsmId.h"

const OsmIdType Osm::MAX_ID = std::numeric_limits<OsmIdType>::max();



