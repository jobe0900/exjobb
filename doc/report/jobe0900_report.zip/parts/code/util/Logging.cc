/*
 * Logging.cc
 */

#include "Logging.h"

//static
bool Logging::isInited {false};

