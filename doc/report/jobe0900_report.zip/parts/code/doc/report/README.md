Report
======

The originals for the project's report. Written in [ShareLaTeX](https://www.sharelatex.com).