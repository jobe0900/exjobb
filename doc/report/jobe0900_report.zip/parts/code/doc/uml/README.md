UML
===

Class and sequence diagrams to get an idea of the concepts, although not 100% accurate.

Diagrams are created in `draw.io`, exported as  `.svg` files, opened in `Inkscape` and saved as `.pdf` files (for usage in report).