/** The Speed type.
 * Speed.h
 *
 * @author  Jonas Bergman
 */

#ifndef GRAPH_SPEED_H_
#define GRAPH_SPEED_H_


typedef unsigned Speed;


#endif /* GRAPH_SPEED_H_ */
