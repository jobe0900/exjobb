/* The Cost type.
 *
 * Cost.h
 *
 * @author  Jonas Bergman
 */

#ifndef GRAPH_COST_H_
#define GRAPH_COST_H_

typedef double Cost;

#endif /* GRAPH_COST_H_ */
